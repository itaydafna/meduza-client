{{ config(materialized='view') }}

select distinct 
sub_attributes.subscriber_key AS subscriber_key,
sub_attributes.city AS city
from sub_attributes

