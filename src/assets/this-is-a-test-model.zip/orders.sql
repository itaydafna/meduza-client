{{ config(materialized='view') }}

select 
orders.subscriber_key AS subscriber_key,
sum(orders.order_count) AS order_count,
sum(orders.order_value) AS order_value
from orders

where orders.date_id BETWEEN 2017121900 AND 2023011723
group by 1
