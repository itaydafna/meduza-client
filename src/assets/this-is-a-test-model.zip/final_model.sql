{{ config(materialized='view') }}

select 
merged_model.campaign AS campaign,
merged_model.city AS city,
sum(merged_model.order_count) AS order_count,
sum(merged_model.order_value) AS order_value
from {{ ref('merged_model') }}
merged_model

group by 1,2
order by order_count ASC
