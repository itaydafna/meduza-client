{{ config(materialized='view') }}

select distinct 
engagement.subscriber_key AS subscriber_key,
engagement.campaign AS campaign
from engagement

where engagement.date_id BETWEEN 2017121900 AND 2023011723
