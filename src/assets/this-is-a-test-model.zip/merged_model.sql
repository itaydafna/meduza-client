{{ config(materialized='view') }}

select 
engagement.campaign AS campaign,
sub_attributes.city AS city,
sum(orders.order_count) AS order_count,
sum(orders.order_value) AS order_value
from {{ ref('engagement') }} engagement

left join {{ ref('orders') }} orders on (engagement.subscriber_key = orders.subscriber_key)
left join {{ ref('sub_attributes') }} sub_attributes on (engagement.subscriber_key = sub_attributes.subscriber_key)
group by 1,2
